/**
 * 
 */
package it.polimi.ingsw.lab.items;

import it.polimi.ingsw.lab.characters.Character;

/**
 * @author fabio
 *
 */
public /*@ pure @*/ abstract class Sword extends Weapon {

	/**
	 * @param name
	 */
	public Sword(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see it.polimi.ingsw.lab.items.Weapon#isEquipable(it.polimi.ingsw.lab.characters.Character)
	 */
	public abstract boolean isEquipable(Map c);
}
