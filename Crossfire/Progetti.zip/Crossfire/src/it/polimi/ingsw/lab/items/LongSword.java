package it.polimi.ingsw.lab.items;

import java.util.HashMap;
import java.util.Map;
import it.polimi.ingsw.lab.characters.Character;
import it.polimi.ingsw.lab.utils.Ability;

public /*@ pure @*/  class LongSword extends Sword {
	
	//*@ requires true
	//*@ ensures this.modificator.get("forza")==20 && this.name.equals("LongSword") && this.modificator.get("destrezza")==-20;
	public LongSword(String LongSword) {
		super(Item.LongSword);
		//this.modificator.put("forza",20);
		//this.modificator.put("destrezza",-20);
	}

	
	
	public Map getModificatorMap(){
		Map m= new HashMap();
		m.putAll(modificator);
		return m;
	}
	
	//*@ requires
	//*@ ensures
	public boolean isEquipable(Map c) {
		Ability f=c.getAbility("forza");
		Ability d=c.getAbility("destrezza");
		/**
		 * ciclo
		 */
		if(f.getValue()<=65 || d.getValue()<20)
			return false;
		return true;
	}

}
