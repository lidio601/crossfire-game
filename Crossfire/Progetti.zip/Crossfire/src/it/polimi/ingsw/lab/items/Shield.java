package it.polimi.ingsw.lab.items;

import it.polimi.ingsw.lab.characters.Character;
import it.polimi.ingsw.lab.utils.Ability;

public class Shield extends Item{

	
	//*@ requires
	//*@ ensures 
	public boolean isEquipAble(Character c) {
		return true;
	}
}
