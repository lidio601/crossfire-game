package it.polimi.ingsw.lab.items;

import it.polimi.ingsw.lab.characters.Character;
import it.polimi.ingsw.lab.utils.Ability;

public class MagicWand extends Item{

	//*@ requires
	//*@ ensures 
	public boolean isEquipAble(Character c) {
		
		Ability am=c.getAbility("abilit�magiche");
		if(am.getValue()<=70)
			return false;
		return true;
	}

}
