/**
 * 
 */
package it.polimi.ingsw.lab.items;

import it.polimi.ingsw.lab.characters.Character;

/**
 * @author fabio
 *
 */
public /*@ pure @*/ abstract class Weapon extends Item {

	/**
	 * @param name
	 */
	public Weapon(String name) {
		super(name);
	}

	/* (non-Javadoc)
	 * @see it.polimi.ingsw.lab.items.Item#isEquipable(it.polimi.ingsw.lab.characters.Character)
	 */
	public abstract boolean isEquipable(Character c);
}
