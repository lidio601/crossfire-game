package it.polimi.ingsw.lab.items;

import it.polimi.ingsw.lab.characters.Character;
import it.polimi.ingsw.lab.utils.Ability;

public class Bow extends Item{
	
	//*@
	//*@
	public boolean isEquipAble(Character c) {
		
		Ability f=c.getAbility("fortuna");
		Ability d=c.getAbility("destrezza");
		int req=f.getValue()+d.getValue();
		if(req<=100)
			return false;
		
		return true;
	}

}
