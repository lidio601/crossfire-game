package it.polimi.ingsw.lab.items;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import it.polimi.ingsw.lab.characters.Character;

public /*@ pure @*/ abstract class Item {
	/**
	 * Valori accettati per il campo nome
	 */
	public static final String LongSword="LongSword";
	public static final String LifePotion="LifePotion";
	public static final String MagicWond="MaginWond";
	public static final String Shield="Shield";
	
	private Map requisiti = new HashMap();
	private Map modificator = new HashMap();
	
	private String name;
	
	/**
	 * i costruttori dei figli devono inserire i requisiti nella mappa
	 * @param name
	 */
	public /*@ pure @*/  Item(String name) {
		this.name = name;
	}
	
	/**
	 * @return the name
	 */
	//@ requires
	//@ ensures
	public /*@ pure @*/  String getName() {
		return new String(name);
	}

	/**
	 * Ritorna un booleano se il Character passato possiede le Ability
	 * necessarie per questo oggetto (il figlio!)
	 * @param c
	 * @return boolean
	 */
	public /*@ pure @*/  abstract boolean isEquipable (Map c);
	
	/**
	 * 
	 */
	public Item clone(Object o) {
		
	}

}
