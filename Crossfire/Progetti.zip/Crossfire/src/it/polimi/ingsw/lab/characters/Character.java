package it.polimi.ingsw.lab.characters;

import it.polimi.ingsw.lab.items.Item;
import it.polimi.ingsw.lab.utils.Ability;
import it.polimi.ingsw.lab.utils.NotValidObjectException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import it.polimi.ingsw.lab.characters.Character;

public class Character {
	/**
	 * Definizione delle costanti per validare il nome
	 * della Razza
	 */
	public static final String Umano = "umano";
	public static final String Orco = "orco";
	public static final String Elfo = "elfo";
	public static final String Mago = "mago";
	/**
	 * Consideriamo la Vita del personaggio come una Ability
	 */
	private /*@ spec_public non_null @*/ String name;
	private /*@ spec_public non_null @*/ Ability life;
	private /*@ spec_public non_null @*/ Map abilities; 
	private /*@ spec_public non_null @*/ List inventory = new ArrayList();
	private /*@ spec_public non_null @*/ Set equipped;
	
	//@ private invariant repOk();
	public /*@ pure @*/ boolean repOk() {
		if(this.name == null || name.equals(""))	return false;
		/**
		 * verifico che le chiavi di abilities siano String
		 */
		Set keys = abilities.keySet();
		Iterator overKeys = keys.iterator();
		while(overKeys.hasNext()) {
			Object o = overKeys.next();
			if(!(o instanceof String)) {
				return false;
			}
		}
		/**
		 * verifico che gli oggetti di abilities siano Ability
		 */
		keys = abilities.entrySet();
		overKeys = keys.iterator();
		while(overKeys.hasNext()) {
			Object o = overKeys.next();
			if(!(o instanceof Ability)) {
				return false;
			}
		}
		//tutti gli oggetti in equipped e owned devono essere Item
		//
		return true;
	}
	//@ name != null && !name.equals("") &&
	//@ (\forall Object o; abilities.containsKey(o); o instanceof String);
	
	//Costruttore
	//@ requires name!=null && !name.equals("");
	//@ ensures this.name.equals(name) && repOk();
	public Character(String name) {
		this.name = name;
		this.abilities = new HashMap();
		this.inventory = new ArrayList();
		this.equipped = new HashSet();
	}
	
	//Getter
	//@ ensures \result.getName().equals(this.getName());
	public String getName() {
		return name;
	}
	// questo metodo dovrebbe restiturti l'abilità corrispondente alla stringa
	public Ability getAbility(String a){
		return new Ability((Ability)this.abilities.get(a));
	}
	
	// questo metodo dovrebbe restiturti l'abilità corrispondente alla stringa
	public Set getAbilities(){
		return new HashSet(this.abilities.entrySet());
	}

	//Setter
	//@ requires name!=null && !name.equals("");
	//@ ensures this.name.equals(name);
	public void setName(String name) {
		this.name = name;
	}
	
	
	public List getInventory() {
		return new ArrayList(this.inventory);
	}
	
	public Set getEquipped() {
		return new HashSet(this.equipped);
	}
	
	//Producers
	/**
	 * lo fa michele
	 */
	public boolean hasItem(String nome) {
		return false;
	}
	
	/**
	 * metodo che raccoglie oggetti e lo mette in inventory(arraylist)
	 * @param i
	 */
	//@ requires true;
	//@ ensures this.inventory.contains(i);
	//@ signals NotValidObjectException
	//@ !(i instanceof Item);
	public void pick(Item i) throws NotValidObjectException {
		if(!(i instanceof Item)) throw new NotValidObjectException();
		this.inventory.add(i);
	}
	
	/**
	 * metodo che raccoglie oggetti e lo mette in inventory(arraylist)
	 * @param i
	 */
	//@ requires this.inventory.contains(i);
	//@ ensures !(this.inventory.contains(\old i));
	//@ signals NotValidObjectException
	//@ !(i instanceof Item);
	public Item drop(Item i) throws NotValidObjectException {
		if(!(i instanceof Item)) throw new NotValidObjectException();
		this.inventory.remove(i);
		return i;
	}
	
	/**
	 * metodo che raccoglie oggetti e lo mette in inventory(arraylist)
	 * @param i
	 */
	//@ requires this.hasItem(nome);
	//@ ensures !(this.inventory.contains(\old i));
	//@ signals NotInListException
	//@ !this.hasItem(nome);
	public Item drop(String nome) throws NotValidObjectException {
		Item i = null;
		//if(!(i instanceof Item)) throw new NotValidObjectException();
		//this.inventory.remove(i);
		return i;
	}
	
	//@ requires this.inventory.contains(i)
	//@ ensures
	//@ signals NotValidObjectException
	//@ !(i instanceof Item);
	public boolean equip(String nome){
		Item i;
		if(!this.hasItem(nome)) {
			//se non c'è esco
			return false;
		}
		// ciclo l'invetory e prendo l'oggetto
		// lo fa fabio
		if(!i.isEquipable(this.getAbilities())) {
			return false;
		}
		//sposto l'item in equiped
		//modifico le abilità
		if(this.repOk()) {
			return true;
		}
		else {
			//tolgo le abilità
			//rimetto l'item in invetory
			return false;
		}
	}
	
	//@ requires 
	//@ ensures
	public Map unEquip(){
		//metodo per togliere equipaggiamento
		return new HashMap();
	}
	
	//@ requires 
	//@ ensures
	public Map setMapAbility() {
		//metodo che setta la mappa di abilit� di un personaggio meglio astratto?
		return new HashMap();
	}
	
	/*
	 * AF(c) = (* ritorna la descrizione di questo oggetto *);
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		String toRet = "Un personaggio di nome " + this.getName() + System.getProperty("line.separator");
		//ciclo sulle abilità sfruttando la toString di Ability
		/////
		return toRet;
	}
}
