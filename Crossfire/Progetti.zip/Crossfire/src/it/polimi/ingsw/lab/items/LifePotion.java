package it.polimi.ingsw.lab.items;

import it.polimi.ingsw.lab.characters.Character;

public class LifePotion extends Item{
	
	//*@ 
	//*@
	public boolean isEquipAble(Character c) {
		//decidere come fare la vita e in base a quello implemetare
		return false;
	}



}
